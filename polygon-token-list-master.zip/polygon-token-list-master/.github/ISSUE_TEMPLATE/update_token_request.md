---
name: Update Token Request
about: Request a token updation
title: 'Update {TOKEN_SYMBOL}: {TOKEN_NAME}'
labels: update token request
assignees: ''
---

**Please only fill in the information you want to update for your token.**

Token Name:
Token Symbol:
Decimals:
Polygon Address:
Ethereum Address:
Logo URI (svg):
Project Name:
Project Summary:
Project Contact:
Project Website:

Additional Notes:
